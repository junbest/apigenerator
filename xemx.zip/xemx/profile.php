<?php include('include/header.php');
	  include('include/functions.php');
	  
	  if(isset($_POST['btn_submit']))
	  {
	  	if($_POST['btn_submit']=='update')
			$data = update_profile();
	  }	
?>

         <?php if(!empty($data)){
		 	
			 echo '<div class="alert alert-'.($data['status']=='error'?'danger':'success').'">'.$data['msg'].'</div>';
			
			}
		 ?>
		  <div class="panel panel-default">
              <div class="panel-heading"><h2 class="text-uppercase">Profile</h2></div>
              <div class="panel-body">
			  <form action="" method="post" class="templatemo-login-form" onsubmit="return validate();">
				<div class="form-group">
				  <label for="inputEmail">Email address</label>
				  <input type="email" class="form-control" id="inputEmail" placeholder="Enter email" value="<?php echo $_SESSION['name'];?>" readonly>
				</div>
				<div class="form-group">                      
				  <label for="old_password">Old Password</label>
				  <input type="password" name="old_password" id="old_password" class="form-control" placeholder="Enter password" required>                                 
				</div> 
				<div class="form-group">                      
				  <label for="password">New Password</label>
				  <input type="password" name="password" id="password" class="form-control" placeholder="Enter password" required>                                 
				</div> 
				<div class="form-group">                      
				  <label for="confirm_password">Confirm Password</label>
				  <input type="password" name="confirm_password" id="confirm_password" class="form-control" placeholder="Enter password"required>                                 
				</div>              
				<div class="form-group col-sm-12 col-sm-offset-5">
				  <button type="submit" type="submit" name="btn_submit" value="update" class="templatemo-blue-button">Save</button>
				</div>
			  </form>
			</div>                
		  </div> <!-- row ends -->
<?php include('include/footer.php');?>
<script>
function validate() {
    var pass = $('input[name=password]').val();
    var repass = $('input[name=confirm_password]').val();
    if(($('input[name=password]').val().length == 0) || ($('input[name=confirm_password]').val().length == 0)){
        alert("New Password and Confirm Password are required");
		return false;
    }
    else if (pass != repass) {
        alert("New Password and Confirm Password does not match");
		return false;
    }
    else {
		return true;
    }
}
</script>