<?php include('include/header.php');
	  include('include/functions.php');
	  
	  if(isset($_POST['btn_submit']))
	  {
	  	if($_POST['btn_submit']=='delete')
			delete_api();
		elseif($_POST['btn_submit']=='generate')
			generate_api();
	  }
	  $data = get_api_details();	
?>
		  
		  <div class="panel panel-default margin-10">
              <div class="panel-heading"><h2 class="text-uppercase">API Key</h2></div>
              <div class="panel-body">
			  <form method="post" onsubmit="return confirm('Are you sure?');" class="templatemo-login-form">
				<div class="form-group">
				  <label>API Key: </label>
				  <p><?php echo $data['api_key'];?></p>
				</div>
				<div class="form-group">                      
				  <label>API Secret: </label>
				  <p><?php echo $data['api_secret'];?></p>         
				</div>              
				
				<div class="form-group col-sm-12 col-sm-offset-5">
				    <?php if($data['api_key']=='' && $data['api_secret']==''){?>
			   
						<button type="submit" name="btn_submit" value="generate" class="btn btn-primary">Generate API</button> 
					<?php }else{ ?>
						<button type="submit" name="btn_submit" value="delete" class="btn btn-danger">Delete API</button> 
					<?php } ?>
				</div>
			  </form>
			</div>                
		  </div>
<?php include('include/footer.php');?>          