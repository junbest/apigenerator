<?php
	include'include/config.php';
	global $con;
	$data = array();
	
	// Now we check if the data from the login form was submitted, isset() will check if the data exists.
	if ( !isset($_POST['username']) ) {
		// Could not get the data that should have been sent.
		$data['msg'] = 'Please fill Email!';
		$data['status'] = 'error';
	}
	
	if ($stmt = $con->prepare('SELECT id FROM users WHERE username = ?')) {
		// Bind parameters (s = string, i = int, b = blob, etc), in our case the username is a string so we use "s"
		$stmt->bind_param('s', $_POST['username']);
		$stmt->execute();
		// Store the result so we can check if the user exists in the database.
		$stmt->store_result();
	
		if ($stmt->num_rows > 0) {
			$stmt->bind_result($id);
			$stmt->fetch();
			// User exists, then reset password and send email.
			$password = generate_rand_str(RESET_PASSWORD_LENGTH);
			$enc_password = md5($password);
			$stmt = $con->prepare('UPDATE users set password=? WHERE id = ?');
			$stmt->bind_param('si',$enc_password, $id);
			$stmt->execute();
			
			$msg = "Hello, ".$_POST['username'];
			$msg.= "\r\n Your Password has been reset.";
			$msg.= "\r\n New Password is : ".$password;
			$msg.= "\r\n\r\nThanks";
			$msg.= "XEMX Payment Gateway API";
			
			mail($_POST['username'],"XEMX Reset Password",$msg);
				
			$data['msg'] = 'Your password is reset, check Email and <a href="login.php">Login</a>';
			$data['status'] = 'success';
			 
		} else {
			$data['msg'] = 'Incorrect Username or Email';
			$data['status'] = 'error';
		}
	
		$stmt->close();
	}
	
?>	