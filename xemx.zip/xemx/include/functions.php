<?php
	include('include/config.php');
	
	// We need to use sessions, so you should always start sessions using the below code.
	if (!isset($_SESSION))
		session_start();
	// If the user is not logged in redirect to the login page...
	if (!isset($_SESSION['loggedin'])) {
		header('Location: login.php');
		exit;
	}
	
	function get_api_details()
	{
		global $con;
		$data = array();
		$stmt = $con->prepare('SELECT id, api_key,api_secret FROM users WHERE id = ?');
		$stmt->bind_param('i', $_SESSION['id']);
		$stmt->execute();
		$stmt->store_result();
		if ($stmt->num_rows > 0) {
			$stmt->bind_result($data['id'], $data['api_key'],$data['api_secret']);
			$stmt->fetch();
		}
		$stmt->close();
		$con->close();
		return $data;
			
	}
	
	function delete_api()
	{
		global $con;
		$data = array();
		$api_key='';
		$api_secret='';
		$stmt = $con->prepare('UPDATE users set api_key=?,api_secret=? WHERE id = ?');
		$stmt->bind_param('ssi',$api_key,$api_secret, $_SESSION['id']);
		$stmt->execute();
		$stmt->close();
	}
	
	function generate_api()
	{
		global $con;
		$data = array();
		$api_key=generate_rand_str(API_KEY_LENGTH);
		$api_secret=generate_rand_str(API_SECRET_LENGTH);
		$stmt = $con->prepare('UPDATE users set api_key=?,api_secret=? WHERE id = ?');
		$stmt->bind_param('ssi',$api_key,$api_secret, $_SESSION['id']);
		$stmt->execute();
		$stmt->close();
	}
	
	function update_profile()
	{
		global $con;
		$data = array();
		
		$stmt = $con->prepare('SELECT id,password FROM users WHERE id = ?');
		$stmt->bind_param('i', $_SESSION['id']);
		$stmt->execute();
		$stmt->store_result();
		if ($stmt->num_rows > 0) {
			$stmt->bind_result($id, $old_password);
			$stmt->fetch();
			if(md5($_POST['old_password'])==$old_password)
			{
				
				if (strlen($_POST['password']) > 20 || strlen($_POST['password']) < 5) {
					$data['msg'] = 'Password must be between 5 and 20 characters long!';
					$data['status'] = 'error';
				}
				else
				{
					$password = md5($_POST['password']);
					$stmt = $con->prepare('UPDATE users set password=? WHERE id = ?');
					$stmt->bind_param('si',$password, $_SESSION['id']);
					$stmt->execute();
					$data['msg'] = 'Password Changed Successfully';
					$data['status'] = 'success';
				}
			}
			else
			{
				$data['msg'] = 'Old Password is Wrong';
				$data['status'] = 'error';
			}	
		}
		
		
		$stmt->close();
		$con->close();
		return $data;
	}
?>