<?php
	include'include/config.php';
	global $con;
	$data = array();
	// Now we check if the data was submitted, isset() function will check if the data exists.
	if (!isset($_POST['username'], $_POST['password'])) {
		// Could not get the data that should have been sent.
		$data['msg'] = 'Please complete the registration form!';
		$data['status'] = 'error';
		
	}
	// Make sure the submitted registration values are not empty.
	elseif (empty($_POST['username']) || empty($_POST['password'])) {
		// One or more values are empty.
		$data['msg'] = 'Please complete the registration form';
		$data['status'] = 'error';
		
	}
	elseif (!filter_var($_POST['username'], FILTER_VALIDATE_EMAIL)) {
		$data['msg'] = 'Username/Email is not valid!';
		$data['status'] = 'error';
	}
	
	elseif (strlen($_POST['password']) > 20 || strlen($_POST['password']) < 5) {
		$data['msg'] = 'Password must be between 5 and 20 characters long!';
		$data['status'] = 'error';
	}
	
	// We need to check if the account with that username exists.
	elseif ($stmt = $con->prepare('SELECT id, password FROM users WHERE username = ?')) {
		// Bind parameters (s = string, i = int, b = blob, etc), hash the password using the PHP password_hash function.
		$stmt->bind_param('s', $_POST['username']);
		$stmt->execute();
		$stmt->store_result();
		// Store the result so we can check if the account exists in the database.
		if ($stmt->num_rows > 0) {
			// Username already exists
			$data['msg'] = 'Username exists, please choose another!';
			$data['status'] = 'error';
		} else {
			// Username doesnt exists, insert new account
			if ($stmt = $con->prepare('INSERT INTO users (username, password,api_key,api_secret) VALUES (?, ?, ?, ?)')) {
				// We do not want to expose passwords in our database, so hash the password and use password_verify when a user logs in.
	
				$password = md5($_POST['password']);
				$api_key=generate_rand_str(API_KEY_LENGTH);
				$api_secret=generate_rand_str(API_SECRET_LENGTH);
	
				$stmt->bind_param('ssss', $_POST['username'], $password, $api_key, $api_secret);
				$stmt->execute();
				
				$data['msg'] = 'You have successfully registered, you can now <a href="login.php" class="alert-link">Login</a>!';
				$data['status'] = 'success';
			} else {
				// Something is wrong with the sql statement, check to make sure accounts table exists with all 3 fields.
				$data['msg'] = 'Some error occured';
				$data['status'] = 'error';
			}
		}
		$stmt->close();
		$con->close();
	} else {
		// Something is wrong with the sql statement, check to make sure accounts table exists with all 3 fields.
		$data['msg'] = 'Some error occured..';
		$data['status'] = 'error';
	}
	
	?>