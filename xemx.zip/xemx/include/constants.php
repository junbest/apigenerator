<?php
define("API_KEY_LENGTH",50);
define("API_SECRET_LENGTH",60);
define("RESET_PASSWORD_LENGTH",15);
define("COPYRIGHTS","Copyright &copy; 2020");
?>